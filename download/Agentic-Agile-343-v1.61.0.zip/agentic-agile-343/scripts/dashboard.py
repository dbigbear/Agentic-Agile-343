"""Dashboard 渲染模块 — 从 collect_telemetry.py 拆分。

负责：模板发现、HTML 生成、单次契约摘要。
"""
import json
import re
from pathlib import Path


class DashboardTemplateError(RuntimeError):
    """Dashboard template or generated document is not safe to publish."""


REQUIRED_TEMPLATE_MARKERS = (
    '<script type="application/json" id="telemetry-data">',
    'id="value-kpi"',
    'id="capability-kpi"',
    'id="efficiency-kpi"',
    'id="evolution-panel"',
    "function renderEfficiencyKpi",
    "function renderEvolutionPanel",
    "(function boot()",
    "DASHBOARD_DATA_UNAVAILABLE",
)
EMBED_PATTERN = re.compile(
    r"<!-- TELEMETRY_EMBED_START -->\s*"
    r'<script type="application/json" id="telemetry-data">(.*?)</script>\s*'
    r"<!-- TELEMETRY_EMBED_END -->",
    re.DOTALL,
)


def validate_dashboard_template_text(text: str) -> None:
    """Fail closed when a candidate lacks any required dashboard contract marker."""
    missing = [marker for marker in REQUIRED_TEMPLATE_MARKERS if marker not in text]
    if text.count("<!-- TELEMETRY_EMBED_START -->") != 1:
        missing.append("single TELEMETRY_EMBED_START marker")
    if text.count("<!-- TELEMETRY_EMBED_END -->") != 1:
        missing.append("single TELEMETRY_EMBED_END marker")
    if missing:
        raise DashboardTemplateError(
            "dashboard template incomplete: " + ", ".join(missing)
        )


def validate_dashboard_document_text(
    text: str,
    *,
    expected_scope: str | None = None,
    expected_task_id: str | None = None,
) -> dict:
    """Validate structure and the embedded telemetry binding of generated HTML."""
    validate_dashboard_template_text(text)
    match = EMBED_PATTERN.search(text)
    if not match:
        raise DashboardTemplateError("dashboard embedded telemetry block is missing")
    try:
        payload = json.loads(match.group(1))
    except json.JSONDecodeError as exc:
        raise DashboardTemplateError("dashboard embedded telemetry is invalid JSON") from exc
    if not isinstance(payload, dict):
        raise DashboardTemplateError("dashboard embedded telemetry root must be an object")
    meta = payload.get("meta")
    if not isinstance(meta, dict):
        raise DashboardTemplateError("dashboard embedded telemetry meta must be an object")
    scope = meta.get("scope")
    task_id = meta.get("task_id")
    if scope not in {"project", "contract"}:
        raise DashboardTemplateError(f"dashboard scope is invalid: {scope}")
    if scope == "contract" and not (
        isinstance(task_id, str)
        and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", task_id)
    ):
        raise DashboardTemplateError("contract dashboard requires a safe task id")
    if scope == "project" and task_id is not None:
        raise DashboardTemplateError("project dashboard task id must be null")
    if expected_scope is not None and meta.get("scope") != expected_scope:
        raise DashboardTemplateError(
            f"dashboard scope mismatch: expected {expected_scope}, got {meta.get('scope')}"
        )
    if expected_task_id is not None and meta.get("task_id") != expected_task_id:
        raise DashboardTemplateError(
            f"dashboard task mismatch: expected {expected_task_id}, got {meta.get('task_id')}"
        )
    return payload


def validate_generated_dashboard(
    path: Path,
    *,
    expected_scope: str | None = None,
    expected_task_id: str | None = None,
) -> dict:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise DashboardTemplateError(f"dashboard cannot be read: {path}: {exc}") from exc
    return validate_dashboard_document_text(
        text,
        expected_scope=expected_scope,
        expected_task_id=expected_task_id,
    )


def find_dashboard_template() -> Path | None:
    """skill assets 模板；也接受项目 governance 已有的 dashboard.html"""
    here = Path(__file__).resolve()
    candidates = [
        here.parent.parent / "assets" / "dashboard.html",
        Path("governance/dashboard.html"),
        Path("governance/dashboards/dashboard.html"),
    ]
    for p in candidates:
        if not p.is_file():
            continue
        try:
            validate_dashboard_template_text(p.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, DashboardTemplateError):
            continue
        return p
    return None


def write_static_dashboard(html_path: Path, telemetry: dict, template: Path | None = None) -> Path:
    """把遥测 JSON 内嵌进 HTML，双击即可用浏览器打开（无需 Server）。"""
    tpl = template or find_dashboard_template()
    if not tpl or not tpl.is_file():
        raise DashboardTemplateError("trusted dashboard template not found")

    try:
        text = tpl.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        raise DashboardTemplateError(f"dashboard template cannot be read: {tpl}: {exc}") from exc
    validate_dashboard_template_text(text)
    # 避免 </script> 打断页面
    payload = json.dumps(telemetry, ensure_ascii=False).replace("</", "<\\/")
    embed = (
        "<!-- TELEMETRY_EMBED_START -->\n"
        f'<script type="application/json" id="telemetry-data">{payload}</script>\n'
        "<!-- TELEMETRY_EMBED_END -->"
    )

    new_text, n = re.subn(
        r"<!-- TELEMETRY_EMBED_START -->.*?<!-- TELEMETRY_EMBED_END -->",
        lambda _m: embed,
        text,
        count=1,
        flags=re.DOTALL,
    )
    if n != 1:
        raise DashboardTemplateError("dashboard telemetry placeholder is ambiguous")
    validate_dashboard_document_text(
        new_text,
        expected_scope=(telemetry.get("meta") or {}).get("scope"),
        expected_task_id=(telemetry.get("meta") or {}).get("task_id"),
    )
    html_path.parent.mkdir(parents=True, exist_ok=True)
    html_path.write_text(new_text, encoding="utf-8")
    return html_path


def summarize_for_index(telemetry: dict) -> dict:
    """单次契约 → 项目 runs 列表中的摘要条目"""
    m = telemetry.get("meta", {})
    v = telemetry.get("value", {})
    c = telemetry.get("capability", {})
    e = telemetry.get("efficiency", {})
    ev = telemetry.get("evolution", {})
    tid = m.get("task_id")
    return {
        "task_id": tid,
        "collected_at": m.get("collected_at"),
        "file": m.get("links", {}).get("contract_telemetry"),
        "dashboard": f"dashboards/dashboard-{tid}.html" if tid else m.get("links", {}).get("dashboard_contract"),
        "goal_accuracy": (v.get("goal_accuracy") or {}).get("display"),
        "first_pass_rate": (v.get("first_pass_rate") or {}).get("display"),
        "autonomy_score": (c.get("autonomy_score") or {}).get("display"),
        "auto_heal_rate": (c.get("auto_heal_rate") or {}).get("display"),
        "context_compression": (e.get("context_compression") or {}).get("display"),
        "knowledge_rate": (ev.get("knowledge_crystallization") or {}).get("display"),
        "token_usage": (telemetry.get("cost") or {}).get("token_usage", 0),
    }
